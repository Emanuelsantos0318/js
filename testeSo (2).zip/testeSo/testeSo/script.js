document.getElementById('userForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Impede o envio padrão do formulário

    //pegar valores dos campos
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;


        //atualizando DIV de resultados
    const resultDiv = document.getElementById('result')

    try {
        //testando e enviando daos com axios
        const response = await axios.post('https://jsonplaceholder.typicode.com/posts', {
            name: name,
            email: email
        });
        //tratando a resposta
        resultDiv.innerHTML = `Dados enviados com sucesso! Nome: ${name}, Email: ${email}`; // Mostra os dados enviados
        
    } catch (error) {
        //tratando erros
        resultDiv.innerHTML = `Erro ao enviar dados: ${error.message}`;
    }
});